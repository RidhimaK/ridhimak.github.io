jQuery inView Plugin
=============
A plugin to add or remove CSS classes to elements that are entering or leaving
from the visible part of the HTML document